import React from 'react';
import Counter from './counter';

const App = () => {
  return <Counter />;
};

export default App;
