import ShopHeader from './shop-header';

export default ShopHeader;