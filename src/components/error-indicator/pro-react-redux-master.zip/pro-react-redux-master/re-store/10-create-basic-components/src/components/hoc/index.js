import withBookstoreService from './with-bookstore-service';

export {
  withBookstoreService
};
