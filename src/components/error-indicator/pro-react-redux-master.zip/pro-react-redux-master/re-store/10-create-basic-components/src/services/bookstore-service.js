
export default class BookstoreService {

  getBooks() {
    return [];
  }

}