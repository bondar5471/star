import PeoplePage from './people-page';
import PlanetsPage from './planets-page';
import StarshipsPage from './starships-page';

export {
  PeoplePage,
  PlanetsPage,
  StarshipsPage
};
