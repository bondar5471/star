import withData from './with-data';

export {
  withData
};
