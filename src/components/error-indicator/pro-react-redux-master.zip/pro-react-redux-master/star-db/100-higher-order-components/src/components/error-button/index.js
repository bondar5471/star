import ErrorButton from './error-button';

export default ErrorButton;
