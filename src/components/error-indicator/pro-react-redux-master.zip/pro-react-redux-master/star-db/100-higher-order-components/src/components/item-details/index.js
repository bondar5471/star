import ItemDetails, { Record } from './item-details';

export default ItemDetails;

export { Record };