MOUNTING
------
constructor() => render() => componentDidMount()


UPDATES
------
New Props
              => render() => componentDidUpdate(
setState()                      prevProps, prevState)


UNMOUNTING
------
componentWillUnmount()


ERROR
------
componentDidCatch()