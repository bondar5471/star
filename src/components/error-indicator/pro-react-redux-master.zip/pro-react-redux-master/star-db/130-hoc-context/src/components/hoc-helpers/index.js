import withData from './with-data';
import withSwapiService from './with-swapi-service';

export {
  withData,
  withSwapiService
};
